## Tree shaking for create react app

Full tree-shaking is automatically available without any configuration when using `react-scripts 5.0.0` or higher. (`webpack > 5.0`)
