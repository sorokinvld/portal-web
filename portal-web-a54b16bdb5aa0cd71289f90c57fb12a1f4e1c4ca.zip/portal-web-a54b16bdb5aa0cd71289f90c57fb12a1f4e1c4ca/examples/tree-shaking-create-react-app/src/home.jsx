import React from 'react'
import { Page, Text, Button } from '@geist-ui/core'

const Home = () => (
  <Page>
    <Text>Hello world.</Text>
    <Button>Action</Button>
  </Page>
)

export default Home
