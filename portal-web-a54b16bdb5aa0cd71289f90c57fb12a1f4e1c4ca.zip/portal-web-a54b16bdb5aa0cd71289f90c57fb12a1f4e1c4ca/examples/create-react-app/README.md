## Create React App Example

This example have been moved here: [geist-ui/react-getting-started](https://github.com/geist-org/react-getting-started)
