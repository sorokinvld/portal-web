import { Card, Page, Text } from '@geist-ui/core'

export default function Index() {
  return (
    <Page>
      <Card>
        <Text>Hello, Geist with Remix</Text>
      </Card>
    </Page>
  )
}
