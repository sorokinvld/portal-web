# Tree shaking with Next.js

## About

Full tree-shaking is automatically available without any configuration when using `next.js 11.0.0` or higher. (`webpack > 5.0`)

In this example, run `yarn analyze` to see the results of the build.
