## With TypeScript Example

This example have been moved here: [geist-ui/react-ts-getting-started](https://github.com/geist-org/react-ts-getting-started)
