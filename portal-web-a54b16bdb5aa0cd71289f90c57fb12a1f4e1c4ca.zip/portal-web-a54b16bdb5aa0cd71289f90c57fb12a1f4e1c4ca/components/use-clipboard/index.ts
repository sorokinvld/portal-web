import useClipboard from './use-clipboard'

export type { UseClipboardOptions, UseClipboardResult } from './use-clipboard'
export default useClipboard
