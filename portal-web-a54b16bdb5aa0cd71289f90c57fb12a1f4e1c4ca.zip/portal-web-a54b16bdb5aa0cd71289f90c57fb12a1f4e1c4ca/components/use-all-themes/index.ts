import { useAllThemes } from './all-themes-context'

export type { AllThemesConfig } from './all-themes-context'
export default useAllThemes
