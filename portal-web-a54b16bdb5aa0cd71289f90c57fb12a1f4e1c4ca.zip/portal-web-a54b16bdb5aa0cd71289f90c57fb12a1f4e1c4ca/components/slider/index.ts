import Slider from './slider'

export type { SliderProps, SliderTypes } from './slider'
export default Slider
