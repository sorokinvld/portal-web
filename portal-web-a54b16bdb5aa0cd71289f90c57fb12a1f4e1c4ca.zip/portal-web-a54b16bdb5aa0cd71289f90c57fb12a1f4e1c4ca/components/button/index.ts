import Button from './button'

export type { ButtonProps } from './button'
export type { ButtonTypes } from '../utils/prop-types'
export default Button
