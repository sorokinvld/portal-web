import { useTheme } from './theme-context'

export default useTheme
