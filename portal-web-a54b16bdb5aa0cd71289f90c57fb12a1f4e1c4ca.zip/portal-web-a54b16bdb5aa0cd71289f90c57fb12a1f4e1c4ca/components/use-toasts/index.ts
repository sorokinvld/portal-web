import useToasts from './use-toast'

export type { ToastAction, Toast, ToastTypes, ToastInput, ToastLayout } from './use-toast'
export default useToasts
