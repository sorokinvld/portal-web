import GeistProvider from './geist-provider'

export type { GeistProviderProps } from './geist-provider'
export default GeistProvider
