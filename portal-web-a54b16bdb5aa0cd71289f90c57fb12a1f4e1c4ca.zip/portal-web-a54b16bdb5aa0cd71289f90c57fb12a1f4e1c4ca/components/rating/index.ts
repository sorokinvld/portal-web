import Rating from './rating'

export type { RatingProps, RatingTypes, RatingCount, RatingValue } from './rating'
export default Rating
