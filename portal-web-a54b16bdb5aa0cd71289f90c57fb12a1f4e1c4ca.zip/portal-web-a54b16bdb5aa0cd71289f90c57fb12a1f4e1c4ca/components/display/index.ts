import Display from './display'

export type { DisplayProps } from './display'
export default Display
