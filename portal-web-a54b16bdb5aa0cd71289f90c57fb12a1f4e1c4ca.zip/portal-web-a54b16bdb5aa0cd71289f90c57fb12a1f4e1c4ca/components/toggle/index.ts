import Toggle from './toggle'

export type {
  ToggleProps,
  ToggleSize,
  ToggleEvent,
  ToggleEventTarget,
  ToggleTypes,
} from './toggle'
export default Toggle
