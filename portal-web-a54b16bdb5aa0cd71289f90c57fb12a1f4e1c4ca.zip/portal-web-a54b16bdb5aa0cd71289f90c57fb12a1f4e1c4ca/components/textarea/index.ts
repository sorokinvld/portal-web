import Textarea from './textarea'

export type { TextareaProps, TextareaResizes, TextareaTypes } from './textarea'
export default Textarea
