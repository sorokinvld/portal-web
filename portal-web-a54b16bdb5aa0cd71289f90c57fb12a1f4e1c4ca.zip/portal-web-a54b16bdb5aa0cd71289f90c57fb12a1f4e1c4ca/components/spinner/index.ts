import Spinner from './spinner'

export type { SpinnerProps } from './spinner'
export default Spinner
