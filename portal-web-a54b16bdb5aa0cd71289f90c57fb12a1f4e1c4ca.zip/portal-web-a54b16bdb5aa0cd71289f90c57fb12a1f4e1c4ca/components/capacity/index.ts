import Capacity from './capacity'

export type { CapacityProps } from './capacity'
export default Capacity
