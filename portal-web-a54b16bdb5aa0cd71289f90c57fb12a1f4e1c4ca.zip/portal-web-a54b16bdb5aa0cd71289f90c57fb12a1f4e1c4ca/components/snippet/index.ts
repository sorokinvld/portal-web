import Snippet from './snippet'

export type { SnippetProps, ToastTypes } from './snippet'
export type { CopyTypes, SnippetTypes } from '../utils/prop-types'
export default Snippet
