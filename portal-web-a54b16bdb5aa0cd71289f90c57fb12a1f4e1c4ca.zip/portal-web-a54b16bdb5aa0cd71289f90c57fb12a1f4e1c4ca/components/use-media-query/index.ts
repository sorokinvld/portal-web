import useMediaQuery from './use-media-query'

export type { ResponsiveBreakpoint, ResponsiveOptions } from './use-media-query'
export default useMediaQuery
