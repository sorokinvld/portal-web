import Loading from './loading'

export type { LoadingProps, LoadingTypes } from './loading'
export default Loading
