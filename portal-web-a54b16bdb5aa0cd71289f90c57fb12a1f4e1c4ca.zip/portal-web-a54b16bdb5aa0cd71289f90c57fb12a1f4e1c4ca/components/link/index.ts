import Link from './link'

export type { LinkProps } from './link'
export default Link
