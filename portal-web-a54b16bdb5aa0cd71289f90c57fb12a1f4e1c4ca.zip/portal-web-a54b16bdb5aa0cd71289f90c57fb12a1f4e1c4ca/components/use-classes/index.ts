import { default as useClasses } from './use-classes'

export default useClasses
