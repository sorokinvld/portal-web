import Note from './note'

export type { NoteProps, NoteTypes } from './note'
export default Note
