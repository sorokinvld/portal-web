import Description from './description'

export type { DescriptionProps } from './description'
export default Description
