import useTabs from './use-tabs'

export default useTabs
