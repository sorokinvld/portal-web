import Keyboard from './keyboard'

export type { KeyboardProps } from './keyboard'
export default Keyboard
