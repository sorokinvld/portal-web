import useBodyScroll from '../use-body-scroll'

export default useBodyScroll
