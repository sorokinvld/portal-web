import { default as useClickAway } from '../use-click-away'

export default useClickAway
