import useClipboard from '../use-clipboard'

export default useClipboard
