import Dot from './dot'

export type { DotProps, DotTypes } from './dot'
export default Dot
