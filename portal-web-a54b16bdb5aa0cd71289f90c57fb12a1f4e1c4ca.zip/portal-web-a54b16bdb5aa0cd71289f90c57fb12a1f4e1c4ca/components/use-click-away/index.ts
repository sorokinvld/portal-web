import useClickAway from './use-click-away'

export default useClickAway
