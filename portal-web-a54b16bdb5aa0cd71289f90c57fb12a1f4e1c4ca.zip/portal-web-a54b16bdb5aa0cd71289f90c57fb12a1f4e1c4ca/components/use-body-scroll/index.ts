import useBodyScroll from './use-body-scroll'

export type { BodyScrollOptions } from './use-body-scroll'
export default useBodyScroll
