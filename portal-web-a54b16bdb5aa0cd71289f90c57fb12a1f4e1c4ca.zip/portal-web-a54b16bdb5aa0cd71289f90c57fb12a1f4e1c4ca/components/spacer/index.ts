import Spacer from './spacer'

export type { SpacerProps } from './spacer'
export default Spacer
