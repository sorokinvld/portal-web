import Divider from './divider'

export type { DividerProps, DividerTypes } from './divider'
export type { DividerAlign } from '../utils/prop-types'
export default Divider
