import Tag from './tag'

export type { TagProps, TagColors, TagTypes } from './tag'
export default Tag
