import Code from './code'

export type { CodeProps } from './code'
export default Code
