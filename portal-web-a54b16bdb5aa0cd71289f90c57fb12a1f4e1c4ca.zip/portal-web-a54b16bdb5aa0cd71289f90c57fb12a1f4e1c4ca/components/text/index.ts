import Text from './text'

export type { TextProps, TextTypes } from './text'
export default Text
