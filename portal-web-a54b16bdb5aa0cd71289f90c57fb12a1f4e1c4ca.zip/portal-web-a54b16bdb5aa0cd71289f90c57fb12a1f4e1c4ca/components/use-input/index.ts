import useInput from './use-input'

export type { BindingsChangeTarget } from './use-input'
export default useInput
