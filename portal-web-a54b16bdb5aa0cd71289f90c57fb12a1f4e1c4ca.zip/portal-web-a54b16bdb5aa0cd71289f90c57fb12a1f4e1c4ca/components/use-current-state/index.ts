import useCurrentState from './use-current-state'

export default useCurrentState
