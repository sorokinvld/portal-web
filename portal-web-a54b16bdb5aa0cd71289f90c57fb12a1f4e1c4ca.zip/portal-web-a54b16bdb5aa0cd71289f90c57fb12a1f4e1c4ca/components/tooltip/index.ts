import Tooltip from './tooltip'

export type {
  TooltipProps,
  TooltipOnVisibleChange,
  TooltipTypes,
  TooltipTriggers,
  TooltipPlacement,
} from './tooltip'
export default Tooltip
