import useModal from './use-modal'

export type { ModalHooksBindings } from './use-modal'
export default useModal
