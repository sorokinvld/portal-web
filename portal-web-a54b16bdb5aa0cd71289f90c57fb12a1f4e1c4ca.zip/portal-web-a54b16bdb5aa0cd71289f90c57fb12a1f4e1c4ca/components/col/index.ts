import Col from './col'

export type { ColProps } from './col'
export default Col
