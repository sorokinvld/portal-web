import Progress from './progress'

export type { ProgressProps, ProgressColors, ProgressTypes } from './progress'
export default Progress
