---
name: "Bug report 🐞"
about: "If something isn't working as expected 🤔."
---

<!-- Please do NOT DELETE the template. -->
<!-- No template issues will be closed. -->

# Bug report 🐞

## Version & Environment

  - Version of browser
  - Version of `geist-ui/core`

## Expected Behaviour

The behavior I expect is ...

## Actual results (or Errors)

I got an error:

```
code
```

