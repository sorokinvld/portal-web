import Attributes from './attributes'
import AttributesTitle from './attributes-title'
import AttributesTable from './attributes-table'

Attributes.Title = AttributesTitle
Attributes.Table = AttributesTable

export default Attributes
