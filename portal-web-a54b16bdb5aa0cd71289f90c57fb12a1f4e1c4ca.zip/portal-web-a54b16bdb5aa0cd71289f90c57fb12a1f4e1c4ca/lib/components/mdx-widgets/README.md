## MDX Widgets

These components are used as examples for mdx files, please do not refer to this content for other components in the `lib` folder.
